import React, { useState } from 'react';
import { Text, SafeAreaView, StyleSheet, TouchableOpacity, View, ImageBackground, ScrollView, LayoutAnimation } from 'react-native';

const grupos = [
  { id: '1', nome: 'Grupo X', descricao: 'Lorem ipsum', curso: 'Psicologia', integrantes: 'Cleber, Antônio, Marina' },
  { id: '2', nome: 'Grupo Y', descricao: 'Lorem ipsum', curso: 'Medicina veterinária', integrantes: 'Joana, Mariana, Jorge' },
  { id: '3', nome: 'Grupo Z', descricao: 'Lorem ipsum', curso: 'Ciência da computação', integrantes: 'João, Lucas, Guilherme' },
  { id: '4', nome: 'Grupo W', descricao: 'Lorem ipsum', curso: 'Arquitetura e Urbanismo', integrantes: 'Jonas, Melissa, Rodrigo' },
];

export default function GroupsPage() {
  const [expandedGroup, setExpandedGroup] = useState(null);

  const handleExpand = (groupId) => {
    // Animação de layout para transição suave
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);

    // Toggle a expansão do grupo
    setExpandedGroup(expandedGroup === groupId ? null : groupId);
  };

  return (
    <ImageBackground source={require('../assets/fundo.png')} style={styles.background} resizeMode="cover">
      <SafeAreaView style={styles.container}>
        <ScrollView contentContainerStyle={styles.groupsContainer}>
          {grupos.map((group) => (
            <View
              key={group.id}
              style={[styles.groupWrapper, expandedGroup === group.id && styles.expandedWrapper]}
            >
              <TouchableOpacity
                style={[styles.groupBox, expandedGroup === group.id && styles.selectedGroup]}
                onPress={() => handleExpand(group.id)}
              >
                <Text style={styles.groupName}>{group.nome}</Text>
              </TouchableOpacity>

              {expandedGroup === group.id && (
                <View style={styles.expandedInfo}>
                  <Text style={styles.infoText}>
                    <Text style={styles.bold}>Descrição:</Text> {group.descricao}
                  </Text>
                  <Text style={styles.infoText}>
                    <Text style={styles.bold}>Curso:</Text> {group.curso}
                  </Text>
                  <Text style={styles.infoText}>
                    <Text style={styles.bold}>Integrantes:</Text> {group.integrantes}
                  </Text>

                  <TouchableOpacity
                    style={styles.closeButton}
                    onPress={() => handleExpand(group.id)}
                  >
                    <Text style={styles.closeButtonText}>X</Text>
                  </TouchableOpacity>
                </View>
              )}
            </View>
          ))}
        </ScrollView>
      </SafeAreaView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  groupsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    paddingVertical: 20,
  },
  groupWrapper: {
    width: '45%',
    margin: 10,
  },
  expandedWrapper: {
    width: '100%',
    marginBottom: 20,
  },
  groupBox: {
    height: 100,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#063970',
    borderRadius: 10,
  },
  selectedGroup: {
    backgroundColor: '#04519a', // Cor de destaque para grupo selecionado
  },
  groupName: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  expandedInfo: {
    backgroundColor: '#f0f0f0',
    borderRadius: 10,
    padding: 10,
    marginTop: 10,
  },
  infoText: {
    fontSize: 14,
    marginBottom: 5,
  },
  bold: {
    fontWeight: 'bold',
  },
  closeButton: {
    marginTop: 10,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#de0215',
    height: 30,
    width: 60,
    borderRadius: 5,
  },
  closeButtonText: {
    color: '#fff',
    fontSize: 16,
  },
});
