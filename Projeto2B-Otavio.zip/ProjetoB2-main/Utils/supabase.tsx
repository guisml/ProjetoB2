import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://sgacacikmfnxatyrrfwy.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNnYWNhY2lrbWZueGF0eXJyZnd5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzAxMTM4MDgsImV4cCI6MjA0NTY4OTgwOH0.G1xi0j7XnR7Ac__NkgXsOodutDkLaF1xDSQK1lNMaQo';


export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);
