export const info = [
 {
   nome:"Grupo X",
   descricao: "Descrição",
   Curso: "Psicologia",
   integrantes:[
     "Cleber",
     "Antônio",
     "Marina"
   ]
 },
 {
   nome:"Grupo Y",
   descricao:"Descrição",
   Curso: "Medicina veterinária",
   integrantes:[
     "Joana",
     "Mariana",
     "Jorge"
   ]
 },
 {
   nome:"Grupo Z",
   descricao:"Descrição",
   Curso: "Ciência da computação",
   integrantes:[
     "João",
     "Lucas",
     "Guilherme"
   ]
 },
 {
  nome:"Grupo W",
  descricao:"Descrição",
  Curso: "Arquitetura e Urbanismo",
  integrantes:[
    "Jonas",
    "Melissa",
    "Rodrigo"
  ]
}

]